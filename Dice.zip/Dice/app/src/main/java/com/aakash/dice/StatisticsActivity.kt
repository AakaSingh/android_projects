package com.aakash.dice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class StatisticsActivity : AppCompatActivity() {

    private lateinit var totalRolls: TextView
    private lateinit var rollsDice1: TextView
    private lateinit var rollsDice2: TextView
    private lateinit var rollsDice3: TextView
    private lateinit var rollsDice4: TextView
    private lateinit var rollsDice5: TextView
    private lateinit var rollsDice6: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_statistics)
        totalRolls = findViewById(R.id.statistics_totalRolls)
        rollsDice1 = findViewById(R.id.statistics_dice1)
        rollsDice2 = findViewById(R.id.statistics_dice2)
        rollsDice3 = findViewById(R.id.statistics_dice3)
        rollsDice4 = findViewById(R.id.statistics_dice4)
        rollsDice5 = findViewById(R.id.statistics_dice5)
        rollsDice6 = findViewById(R.id.statistics_dice6)

        val myIntent = intent
        if (myIntent.hasExtra(MainActivity.EXTRA_STATISTICS)) {
            val sss = myIntent.extras
            val statisticsArray = sss?.getIntArray(MainActivity.EXTRA_STATISTICS)
            totalRolls.text = "Total Rolls : " + (statisticsArray!!.sum()).toString()
            rollsDice1.text = "Dice 1 :" + statisticsArray[0].toString()
            rollsDice2.text = "Dice 2 :" + statisticsArray[1].toString()
            rollsDice3.text = "Dice 3 :" + statisticsArray[2].toString()
            rollsDice4.text = "Dice 4 :" + statisticsArray[3].toString()
            rollsDice5.text = "Dice 5 :" + statisticsArray[4].toString()
            rollsDice6.text = "Dice 6 :" + statisticsArray[5].toString()
        }
    }
}