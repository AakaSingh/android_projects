package com.aakash.dice

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    companion object{
        const val EXTRA_STATISTICS = "all_stats"
    }
    private lateinit var result: ImageView
    private var images = arrayOf(R.drawable.dice1,R.drawable.dice2,R.drawable.dice3,R.drawable.dice4,R.drawable.dice5,R.drawable.dice6)
    private var statistics = arrayOf(0,0,0,0,0,0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        result = findViewById(R.id.main_result)

        val statisticsButton = findViewById<Button>(R.id.main_statistics)
        val rollDice = findViewById<Button>(R.id.main_rollDice)
        rollDice.setOnClickListener(this::onDiceRoll)
        statisticsButton.setOnClickListener(this::toStatsPage)
    }

    private fun onDiceRoll(view: View){
        val diceResultValue = (1..6).random()
        result.setImageResource(images[diceResultValue-1])
        statistics[diceResultValue-1] += 1
    }

    private fun toStatsPage(view: View){
        val intent = Intent(this,StatisticsActivity::class.java).apply {
            putExtra(EXTRA_STATISTICS,statistics)
        }
        startActivity(intent)
    }
}